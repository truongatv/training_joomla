<?php
/**
 * @package		Joomla.Site
 * @subpackage	mod_menu
 * @copyright	Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;

// Note. It is important to remove spaces between elements.
//PHOCAEDIT
if ($item->level == 1 && $item->deeper) {
	$class = $item->anchor_css ? 'class="'.$item->anchor_css.' dropdown-toggle toplevel" ' : 'class="dropdown-toggle toplevel" data-toggle="dropdown" data-hover="dropdown" data-delay="1000" data-close-others="false" ';
	$caret = '<b class="caret"></b>';
} else if ($item->level == 1) {
	$class = $item->anchor_css ? 'class="'.$item->anchor_css.' toplevel" ' : 'class="toplevel"';
	$caret = '';
} else {
	$class = $item->anchor_css ? 'class="'.$item->anchor_css.'" tabindex="-1"' : 'tabindex="-1"';
	$caret = '';
}
$title = $item->anchor_title ? 'title="'.$item->anchor_title.'" ' : '';

if ($item->menu_image) {
	$item->params->get('menu_text', 1 ) ?
	$linktype = '<img src="'.$item->menu_image.'" alt="'.$item->title.'" /><span class="image-title">'.$item->title.'</span> ' :
	$linktype = '<img src="'.$item->menu_image.'" alt="'.$item->title.'" />';
}
else { 
	$linktype = $item->title;
}

$flink = $item->flink;
$flink = JFilterOutput::ampReplace(htmlspecialchars($flink));

switch ($item->browserNav) {
	default:
	case 0:
		echo '<a href="'.$flink.'" '.$title.' '.$class.' >'.$linktype.' '.$caret.'</a>';
	break;
	case 1:
		echo '<a href="'.$flink.'" '.$title.' '.$class.' target="_blank" >'.$linktype.' '.$caret.'</a>';
	break;
	case 2:
		// window.open
		$options = 'toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,'.$params->get('window_open');
		echo '<a href="'.$flink.'" '.$title.' '.$class.' onclick="window.open(this.href,\'targetWindow\',\''. $options.'\');return false;" >'.$linktype.' '.$caret.'</a>';
	break;
}
?>
